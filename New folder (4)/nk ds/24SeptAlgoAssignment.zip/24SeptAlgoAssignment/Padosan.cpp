#include<iostream>
using namespace std;
class AdjSq{
	public:
		void squareNumberAndAdjacentSquare(int n, int number[],int adjSqNo[]){
			for(int i=0; i<n; i++){
				cout<<number[i] << " " <<adjSqNo[i]<<endl;
			}
			
		}
};
int main(){
	int numberOfSq,squareNo[20],count=0, adj[20];
	int xCoordinate1[100],yCoordinate1[100],
	    xCoordinate2[100],yCoordinate2[100],
		xCoordinate3[100],yCoordinate3[100],
		xCoordinate4[100],yCoordinate4[100];
	cin>>numberOfSq;
	for(int i=0; i<numberOfSq; i++){
		cin>>xCoordinate1[i]>>yCoordinate1[i]>>xCoordinate2[i]>>yCoordinate2[i]>>xCoordinate3[i]>>yCoordinate3[i]>>xCoordinate4[i]>>yCoordinate4[i];
		squareNo[i] = i+1;
	}
	for(int k=0; k<numberOfSq; k++){
		for(int j=0; j<numberOfSq; j++){
			if(xCoordinate2[k]==xCoordinate1[j] && yCoordinate2[k] == yCoordinate1[j] && xCoordinate3[k]==xCoordinate4[j] && yCoordinate3[k] == yCoordinate4[j]){
				count++;
			}
			if(xCoordinate4[k]==xCoordinate1[j] && yCoordinate4[k] == yCoordinate1[j] && xCoordinate3[k]==xCoordinate2[j] && yCoordinate3[k] == yCoordinate2[j]){
				count++;
			}
			if(xCoordinate1[k]==xCoordinate2[j] && yCoordinate1[k] == yCoordinate2[j] && xCoordinate4[k]==xCoordinate3[j] && yCoordinate4[k] == yCoordinate4[j]){
				count++;
			}
			if(xCoordinate1[k]==xCoordinate4[j] && yCoordinate1[k] == yCoordinate4[j] && xCoordinate2[k]==xCoordinate3[j] && yCoordinate2[k] == yCoordinate3[j]){
				count++;
			}
		}
		adj[k]=count;
		count = 0;
	}
	AdjSq obj;
		obj.squareNumberAndAdjacentSquare(numberOfSq, squareNo, adj);
	return 0;
}
